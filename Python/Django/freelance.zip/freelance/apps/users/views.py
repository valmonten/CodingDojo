# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse

# Create your views here.

def register(request):
    return HttpResponse('Placeholder for registering')
def login(request):
    return HttpResponse('Placeholder for login')
def new(request):
    return HttpResponse('Placeholder for registering')
def users(request):
    return HttpResponse('Placeholder for users')