# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect

# Create your views here.
def index(request):
    return render(request, 'surveys/index.html')
def process(request):
    print request.POST['name']    
    request.session['name']=request.POST['name']
    request.session['location']=request.POST['location']
    request.session['language']=request.POST['language']
    request.session['comments']=request.POST['comments']
    return redirect('/results')
def results(request):

    return render(request, 'surveys/results.html')
def back(request):
    return redirect('/')