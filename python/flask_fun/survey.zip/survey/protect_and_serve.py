from flask import Flask, render_template, redirect, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")
@app.route('/process', methods=['POST'])
def create_user():
    print "Got User"
    name=request.form['namey']
    location=request.form['location']
    language=request.form['language']
    comments=request.form['comments']
    print request.form
    return render_template('info.html', name=name, location=location, language=language, comments=comments)
app.run(debug=True)