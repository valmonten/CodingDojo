﻿using System;

namespace Wizard__Ninja__Samurai
{
    public class Human
{
    public string name;

    //The { get; set; } format creates accessor methods for the field specified
    //This is done to allow flexibility
    public int health { get; set; }
    public int strength { get; set; }
    public int intelligence { get; set; }
    public int dexterity { get; set; }
    public int maxhealth { get; set; }
    public Human(string person)
    {
        name = person;
        strength = 3;
        intelligence = 3;
        dexterity = 3;
        health = 100;
        maxhealth = 100;
    }
    public Human(string person, int str, int intel, int dex, int hp)
    {
        name = person;
        strength = str;
        intelligence = intel;
        dexterity = dex;
        health = hp;
        maxhealth=100;
    }
    public void attack(object obj)
    {
        Human enemy = obj as Human;
        if(enemy == null)
        {
            Console.WriteLine("Failed Attack");
        }
        else
        {
            int dmg = strength * 5;
            enemy.health -= dmg;
            System.Console.WriteLine("{0} was attacked by {3} for {1} health!, {0} has {2} health left",enemy.name,dmg,enemy.health,name);
        }
    }
}
    public class Wizard : Human{
        
        public Wizard(string person) : base(person, 1, 25, 2, 50){
            System.Console.WriteLine("You are a wizard {0}", person);
            maxhealth = 50;
        }
        public void heal(){
            int incr = 10*intelligence;
            health += incr;
            if(health>maxhealth){
                health=maxhealth;
            }
            System.Console.WriteLine("{2} healed {0} health points. {2} is at {1} health.",incr,health,name);
        }
        public void fireball(object obj){
            Human enemy = obj as Human;
            if(enemy == null){
                System.Console.WriteLine("Failed attack");

            }
            else{
                Random rand = new Random();
                int dmg =rand.Next(20,50);
                enemy.health-=dmg;
                System.Console.WriteLine("{3} did {0} damage. {1}'s remaining health is {2}", dmg,enemy.name,enemy.health,name);
            }
        }
    }
    public class Ninja : Human{
        public Ninja(string person) : base(person,3,3,175,100){
            System.Console.WriteLine("The ninja by the name of {0} was stealthily born",person);
        }
        public void steal(object obj){
            Human enemy = obj as Human;
            if(enemy == null){
                System.Console.WriteLine("Steal failed!");
            }
            else{
                int dmg=strength*5;
                enemy.health-=dmg;
                health+=10;
                if(health>maxhealth){
                    health=maxhealth;

                }
                System.Console.WriteLine("{0} stole healing pots from {1}, and healed for 10 health! {0}'s health is now {2} and {1}'s health is now {3}",name,enemy.name,health,enemy.health);
            }
        }
        public void get_away(){
            health-=15;
            System.Console.WriteLine("{0} Escaped in a cloud of smoke! His health is now {1}",name,health);
        }
        
    }
    public class Samurai : Human{
        public int how_many =0;
        public Samurai(string person) : base(person){
            maxhealth=200;
            health=200;
            how_many++;
            System.Console.WriteLine("An honorable samurai named {0} marches forth looking like he is ready to do battle.",person);
        }
        public void death_blow(object obj){
            Human enemy = obj as Human;
            if(enemy==null){
                System.Console.WriteLine("{0}'s Death Blow failed!",name);
            }
            else{
                if(enemy.health<50){
                    enemy.health=0;
                    System.Console.WriteLine("Death Blow from {0} killed {1}",name,enemy.name);
                }
                else{
                    System.Console.WriteLine("{0}'s Death Blow failed because {1}'s health was too high!", name,enemy.name);
                }
            }
        }
        public void meditate(){
            health=maxhealth;
            System.Console.WriteLine("{0} Healed to max health through meditation!",name);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Wizard Harry = new Wizard("Harry");
            Human Loki = new Human("Loki");
            Ninja Noname = new Ninja("Noname");
            Samurai Sam = new Samurai("Sam");
            Loki.attack(Harry);
            Harry.heal();
            Noname.steal(Loki);
            Noname.steal(Loki);
            Noname.steal(Loki);
            Harry.fireball(Noname);
            Noname.steal(Harry);
            Noname.get_away();
            Harry.fireball(Sam);
            Sam.death_blow(Loki);
            Harry.fireball(Sam);
            Sam.attack(Harry);
            Harry.fireball(Sam);
            Sam.death_blow(Harry);
            Sam.meditate();

        }
    }
}
