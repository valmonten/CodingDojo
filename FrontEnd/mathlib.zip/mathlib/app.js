const mathlib = require('./mathlib')

mathlib.add(2,4);
console.log(mathlib.multiply(2,5));
console.log(mathlib.square(82));
console.log(mathlib.random(100,7));